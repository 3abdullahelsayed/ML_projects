# Anemia Types Classification (CBC blood tests)

Predict one of 9 diagnoses (healthy + 8 conditions) from 14 complete-blood-count (CBC) values, then wrap the model in a small Gradio demo.

| | |
|---|---|
| **Task** | Multi-class classification (9 imbalanced classes) |
| **Data** | Kaggle `ehababoelnaga/anemia-types-classification`: 1,281 patients, 14 CBC features |
| **Model** | Random Forest (100 trees, `class_weight='balanced'`, `ccp_alpha=0.02`) |
| **Result** | **97.8% test accuracy**, macro F1 0.94 (321 test samples) |

## Approach
- Encoded the 9 diagnosis labels as integers.
- Stratified 75/25 train/test split (`random_state=13`) so rare classes appear in both sets. Class sizes range from 336 (Healthy) down to 11 (Leukemia with thrombocytopenia).
- Random Forest with balanced class weights to compensate for the imbalance.
- Gradio demo: enter 14 comma-separated CBC values and get the diagnosis name back.

## Results
Train accuracy 98.0% vs. test accuracy 97.8%, so there is no sign of overfitting.

| Class | Test samples | Precision | Recall |
|---|---:|---:|---:|
| Healthy | 84 | 1.00 | 1.00 |
| Normocytic hypochromic anemia | 70 | 1.00 | 0.96 |
| Normocytic normochromic anemia | 67 | 1.00 | 0.97 |
| Iron deficiency anemia | 47 | 0.98 | 1.00 |
| Thrombocytopenia | 18 | 1.00 | 1.00 |
| Other microcytic anemia | 15 | 1.00 | 0.87 |
| Leukemia | 12 | 0.86 | 1.00 |
| Macrocytic anemia | 5 | 0.62 | 1.00 |
| Leukemia with thrombocytopenia | 3 | 0.75 | 1.00 |

## Limitations & next steps
- Educational project only, **not a diagnostic tool**.
- The rarest classes have only 3-5 test samples, so their scores are unstable. Cross-validation would give a more reliable estimate.
- The source data has suspicious values (e.g. HGB 0.4 with HCT 316 in row 4), and the quartiles of `LYMp`/`LYMn`/`NEUTp`/`NEUTn` all equal the column mean, which suggests mean-imputation in the original dataset. None of this is cleaned here.
- Worth checking how the labels were produced: if they derive from CBC thresholds, high accuracy is partly expected.
- Next: feature-importance analysis, outlier handling, and deploying the demo to Hugging Face Spaces.
