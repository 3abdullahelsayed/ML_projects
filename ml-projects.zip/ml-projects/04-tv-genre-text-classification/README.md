# TV Series Genre Classification from Plot Descriptions (NLP)

Predict a show's genre from its text description using classic NLP.

> The Kaggle dataset is called "IMDB" but it is a catalogue of TV series and streaming titles, so this is genre prediction, not movie-review sentiment analysis.

| | |
|---|---|
| **Task** | Multi-class text classification (3 genres) |
| **Data** | Kaggle `payamamanat/imbd-dataset`: 9,957 titles, reduced to 1,658 rows in 3 genres (Drama 587, Animation/Action/Adventure 553, Documentary 518) |
| **Model** | NLTK tokenization + WordNet lemmatization, TF-IDF (1-2 grams, 10k features), Multinomial Naive Bayes |
| **Result** | **81.9% test accuracy** (332 test samples); 95.7% on train |

## Approach
- Kept the three most common single-label genre groups so each class has enough examples.
- Cleaned the descriptions with word tokenization and lemmatization.
- Vectorized with TF-IDF unigrams + bigrams (10,000 features).
- Stratified 80/20 split (`random_state=42`), Multinomial Naive Bayes.

## Results

| Class | Precision | Recall | F1 |
|---|---:|---:|---:|
| Drama | 0.71 | 0.92 | 0.80 |
| Animation / Action / Adventure | 0.90 | 0.85 | 0.87 |
| Documentary | 0.92 | 0.67 | 0.78 |

The main error is Documentary predicted as Drama (30 of 104 documentaries). The model is also clearly overfit (95.7% train vs 81.9% test).

## Limitations & next steps
- The TF-IDF vectorizer is fitted on the whole dataset before the train/test split, which leaks a little vocabulary information. Fit it on the training set only (e.g. in a `Pipeline`).
- Stop-word removal is imported but not applied.
- Some rows have placeholder descriptions such as "Add a Plot"; these should be filtered out.
- Next: try Logistic Regression / linear SVM on the same features, add cross-validation, and compare against sentence embeddings.
