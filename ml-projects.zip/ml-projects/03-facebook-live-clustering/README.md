# Facebook Live Sellers in Thailand: Clustering

Unsupervised segmentation of Facebook posts from Thai fashion and cosmetics sellers, based on their engagement.

| | |
|---|---|
| **Task** | Clustering (unsupervised) |
| **Data** | UCI dataset #488: 7,050 posts from 10 retail seller pages (4,288 photos, 2,334 videos, 365 statuses, 63 links) |
| **Model** | K-Means on standardized features, visualized with PCA (2D and 3D) |
| **Result** | Best silhouette at **K = 2 (≈ 0.58)**; the final model uses K = 3 (≈ 0.30) |

## Approach
- Label-encoded `status_type`, split the publish timestamp into year / month / day / hour / minute, and standardized all 15 features.
- Searched K = 2…19 using both the elbow method and the silhouette score.
- Fitted K-Means with K = 3 and projected the clusters to 2D and 3D with PCA.

## Results

| K | Silhouette |
|---|---|
| 2 | ≈ 0.58 |
| 3 | ≈ 0.30 |
| 4-19 | ≈ 0.15-0.19 |

(Values read from the plot below.) Only K = 2 gives clearly separated clusters, and the elbow curve has no sharp bend.

![Elbow and silhouette](images/elbow_silhouette.png)
![PCA of the K=3 clusters](images/kmeans_pca_2d.png)

## Limitations & next steps
- The final model uses K = 3 although the silhouette score favors K = 2. The reason for that choice isn't documented in the notebook and should be added.
- Date parts such as year and minute are probably noise as numeric features, and label-encoded `status_type` implies an order that doesn't exist (one-hot encoding would be cleaner).
- Engagement counts are heavy-tailed, so a few viral posts likely dominate the distances. A log transform or robust scaling is worth testing.
- The clusters aren't profiled. Next step: average reactions / shares / post type per cluster to say what each group actually represents.
