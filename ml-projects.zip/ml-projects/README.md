# Machine Learning Projects

**Abdullah Elsayed**

Selected machine-learning projects covering classification, regression, clustering, NLP and deep learning. Each folder has one notebook and a README with the problem, data, approach, results and honest limitations.

| # | Project | Type | Techniques | Headline result |
|---|---|---|---|---|
| 1 | [Anemia types classification](01-anemia-classification) | Multi-class classification | Random Forest, class weighting, Gradio demo | 97.8% test accuracy, macro F1 0.94 |
| 2 | [CNN image classification](02-cnn-image-classification) | Deep learning (vision) | Keras CNN, data augmentation | 83.1% test accuracy on 64 classes |
| 3 | [Facebook Live sellers clustering](03-facebook-live-clustering) | Unsupervised | K-Means, PCA, silhouette / elbow | Silhouette ≈ 0.58 at K = 2 |
| 4 | [TV genre from plot text](04-tv-genre-text-classification) | NLP | Lemmatization, TF-IDF, Naive Bayes | 81.9% test accuracy (3 genres) |
| 5 | [Bankruptcy prediction](05-bankruptcy-prediction) | Imbalanced classification | Decision Tree, class weights | 69% recall on the bankrupt class |
| 6 | [Gas turbine NOx regression](06-gas-turbine-nox-regression) | Regression | Random Forest, RandomizedSearchCV | R² = 0.883 on test |

## Tech stack
Python, pandas, NumPy, scikit-learn, TensorFlow / Keras, NLTK, Matplotlib, Seaborn, Gradio.

## Running the notebooks
1. `pip install -r requirements.txt`
2. Open any notebook in Jupyter or Google Colab (they were developed on Colab).
3. Datasets are downloaded automatically from UCI (`ucimlrepo`) or Kaggle (`kagglehub`). The exception is project 2, whose image dataset is not included; see its README.
