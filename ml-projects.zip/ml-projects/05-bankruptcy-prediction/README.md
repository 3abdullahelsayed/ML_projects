# Taiwanese Company Bankruptcy Prediction (imbalanced classification)

Predict whether a company goes bankrupt from 95 financial ratios, where only about 3% of companies are bankrupt.

| | |
|---|---|
| **Task** | Binary classification, highly imbalanced |
| **Data** | UCI dataset #572: 6,819 companies, 95 features, 220 bankrupt (3.2%) |
| **Model** | Decision Tree (entropy, `max_depth=5`, `max_features=20`, `ccp_alpha=0.009`, `class_weight={0: 4, 1: 25}`) |
| **Result** | **69% recall** on bankrupt companies at **29% precision** (test) |

## Approach
- Stratified 75/25 split (`random_state=13`) to keep the bankrupt share equal in train and test.
- A shallow, pruned tree with heavy class weights on the bankrupt class so the model doesn't just predict "not bankrupt".

## Results (test set, 1,705 companies)

| | Predicted healthy | Predicted bankrupt |
|---|---:|---:|
| **Actually healthy** | 1,556 | 94 |
| **Actually bankrupt** | 17 | 38 |

- Accuracy is 93.5%, but that number is misleading: always predicting "healthy" would score 96.8%.
- Bankrupt class: precision 0.29, recall 0.69, F1 0.41. The model catches 38 of 55 bankruptcies at the cost of 94 false alarms.
- Train recall was 0.87, so the model generalizes worse on the minority class.

## Limitations & next steps
- Hyperparameters were set by hand (the notebook has scratch notes with other values) without a separate validation set, so the test score is probably a bit optimistic. Use cross-validated search instead.
- Evaluate with PR-AUC / ROC-AUC and choose the decision threshold on purpose, based on the cost of a missed bankruptcy vs. a false alarm.
- Try ensemble models and resampling (SMOTE) and compare with this baseline.
