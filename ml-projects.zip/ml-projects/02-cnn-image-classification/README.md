# Image Classification with a CNN (64 classes)

A convolutional neural network built from scratch in Keras and trained in stages on a 64-class image dataset.

| | |
|---|---|
| **Task** | Multi-class image classification (64 classes, chance level ≈ 1.6%) |
| **Data** | 9,200 train / 2,301 val / 2,876 test images (fold 1 of a CSV split). Project dataset, **not included in this repo**.
64 classes of differnt animal.* |
| **Model** | 3 conv blocks (64→128→256 filters) + Dense 128→64 with Dropout 0.3, 22.5M parameters, 224×224×3 input |
| **Result** | **83.1% test accuracy** (83.5% on the validation set at the end of training) |

## Approach
- Data augmentation on the training set: rotation 20°, width/height shift 0.2, shear 0.2, zoom 0.2, horizontal flip.
- Adam optimizer, categorical cross-entropy.
- Trained in four stages (30 epochs in total). The learning rate was raised from 1e-4 to 1e-3 after the first stage because training was too slow.

## Results

| Stage | Learning rate | Epochs | Test accuracy |
|---|---|---:|---:|
| 1 | 1e-4 | 10 | 46.5% |
| 2 | 1e-3 | 5 | 65.0% |
| 3 | 1e-3 | 10 | 79.3% |
| 4 | 1e-3 | 5 | **83.1%** |

Final epoch: train accuracy 77.3%, validation accuracy 83.5%. Training accuracy is lower than validation because augmentation and dropout are active during training. The curve was still improving when training stopped, so the model is probably under-trained.

## Limitations & next steps
- The test set was evaluated after every stage and training continued afterwards, so test results influenced when to stop. The validation accuracy (83.5%) is the cleaner number to quote; ideally decisions would be made on validation only.
- No pretrained baseline. A transfer-learning model (e.g. MobileNet or EfficientNet) would likely be faster to train and more accurate.
- Add a per-class report and confusion matrix to see which of the 64 classes are confused.

## How to run
The data-loading cell reads from a `DATA_DIR` variable. Set it to the folder that contains your images and the `csv/splits_csv/fold_1/{train,val,test}.csv` files (columns `image_path` and `label`). The Google Drive mount cell is only needed on Colab.
