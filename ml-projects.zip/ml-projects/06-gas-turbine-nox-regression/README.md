# Gas Turbine NOx Emission Prediction (regression)

Predict nitrogen-oxide (NOx) emissions of a gas turbine from sensor readings.

| | |
|---|---|
| **Task** | Regression (target: `NOX`) |
| **Data** | UCI dataset #551: 36,733 records (2011-2015), 11 features: `year`, `AT`, `AP`, `AH`, `AFDP`, `GTEP`, `TIT`, `TAT`, `TEY`, `CDP`, `CO` |
| **Model** | Random Forest Regressor (150 trees, `min_samples_leaf=4`, `min_samples_split=4`, `ccp_alpha=0.02`) |
| **Result** | **R² = 0.883**, MSE = 15.24 (RMSE ≈ 3.9) on the test set |

## Approach
- 80/20 random split (`random_state=13`).
- Random Forest baseline, then `RandomizedSearchCV` (10 candidates, 3-fold) over the main hyperparameters.

## Results

| | R² | MSE |
|---|---:|---:|
| Train | 0.914 | 11.87 |
| Test | 0.883 | 15.24 |

For context, the standard deviation of NOx is 11.7, so the typical error (RMSE ≈ 3.9) is roughly a third of that. The search's best cross-validated MSE was 14.72, close to the test MSE, so the original model was already near the best configuration found.

## Limitations & next steps
- 6 of the 30 cross-validation fits failed because `max_features='auto'` is no longer accepted by recent scikit-learn versions. Replace it (e.g. with `1.0`) and re-run so the notebook has no warnings.
- The final test numbers are from the original model, not a refit with the search's best parameters.
- The records are time-ordered (`year` is a feature), so a random split may be optimistic. Compare with a split by year.
- `CO` is itself an emission measurement; check whether it would be available when the model is used in practice.
- Next: gradient boosting (XGBoost / LightGBM), feature importance, and residual plots.
